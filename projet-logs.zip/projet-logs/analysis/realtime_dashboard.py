from pywebio import start_server
from pywebio.output import *
from pywebio.pin import *
import pandas as pd
import time

def dashboard():
    put_markdown("# 📊 Analyse Temps Réel des Logs")
    
    while True:
        # Simulation de données (remplacer par lecture réelle)
        errors = pd.DataFrame({
            'status': [404, 500, 403],
            'count': [45, 12, 8]
        })
        
        put_row([
            put_column([
                put_markdown("### 🔴 Erreurs HTTP"),
                put_table(errors.values.tolist(), header=errors.columns.tolist())
            ]),
            put_column([
                put_markdown("### 🌐 IPs Actives"),
                put_table(pd.DataFrame({
                    'ip': ['192.168.1.1', '10.0.0.15'],
                    'requêtes': [120, 85]
                }).values.tolist())
            ])
        ])
        
        time.sleep(5)  # Rafraîchissement automatique
        clear()  # Pour l'effet temps réel

if __name__ == '__main__':
    start_server(dashboard, port=8080, debug=True)