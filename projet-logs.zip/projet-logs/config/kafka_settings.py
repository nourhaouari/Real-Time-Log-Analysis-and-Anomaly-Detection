KAFKA = {
    "bootstrap_servers": "localhost:9092",
    "topic": "web_logs",
    "consumer_group": "spark_consumer"
}