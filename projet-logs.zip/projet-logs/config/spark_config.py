SPARK = {
    "app_name": "LogAnalyzer",
    "master": "local[*]",
    "config": {
        "spark.sql.shuffle.partitions": "4",
        "spark.driver.memory": "2g"
    }
}