import os
import json
from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col, desc
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# ✅ Configuration pour Windows : winutils et Java
os.environ["HADOOP_HOME"] = "D:\\hadoop-3.3.5"
os.environ["PATH"] += os.pathsep + os.path.join(os.environ["HADOOP_HOME"], "bin")
os.environ["JAVA_HOME"] = "D:\\java\\jdk8"  # change si besoin

# ✅ Schéma des logs (JSON depuis Kafka)
schema = StructType([
    StructField("timestamp", IntegerType()),
    StructField("ip", StringType()),
    StructField("method", StringType()),
    StructField("url", StringType()),
    StructField("status", IntegerType())
])

# ✅ Initialiser Spark avec Kafka
spark = SparkSession.builder \
    .appName("RealTimeLogAnalysis") \
    .config("spark.sql.streaming.forceDeleteTempCheckpointLocation", "true") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0") \
    .getOrCreate()

# ✅ Lire les données depuis Kafka
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "test-topic") \
    .option("startingOffsets", "latest") \
    .load()

# ✅ Parsing JSON
logs = df.selectExpr("CAST(value AS STRING)") \
    .select(from_json(col("value"), schema).alias("data")) \
    .select("data.*")

# ✅ Nouvelle fonction pour écrire dans summary.json
def write_summary(batch_df, batch_id):
    if batch_df.isEmpty():
        return

    top_ips = batch_df.groupBy("ip").count().orderBy(desc("count")).limit(5)
    top_urls = batch_df.groupBy("url").count().orderBy(desc("count")).limit(5)
    errors = batch_df.filter(col("status") >= 400)

    summary = {
        "top_ips": [row.asDict() for row in top_ips.collect()],
        "top_urls": [row.asDict() for row in top_urls.collect()],
        "errors": [row.asDict() for row in errors.collect()]
    }

    with open("D:/projet-logs/results/summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=4)

# ✅ Lancer le stream avec foreachBatch
logs.writeStream \
    .foreachBatch(write_summary) \
    .outputMode("append") \
    .start() \
    .awaitTermination()
