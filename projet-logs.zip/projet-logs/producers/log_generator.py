import random
import time
from datetime import datetime
from faker import Faker

fake = Faker()

methods = ["GET", "POST", "PUT", "DELETE", "PATCH"]
resources = ["/", "/home", "/products", "/contact", "/api/data", "/login", "/admin"]
status_codes = [200, 301, 404, 500, 403]

def generate_log():
    ip = fake.ipv4()
    method = random.choice(methods)
    resource = random.choice(resources)
    status = random.choice(status_codes)
    timestamp = datetime.now().strftime("%d/%b/%Y:%H:%M:%S %z")
    
    return f'{ip} - - [{timestamp}] "{method} {resource} HTTP/1.1" {status} {random.randint(100, 2000)}'

if __name__ == "__main__":
    with open("web_logs.log", "a") as f:
        while True:
            log = generate_log()
            print(log)
            f.write(log + "\n")
            f.flush()
            time.sleep(random.uniform(0.1, 1))