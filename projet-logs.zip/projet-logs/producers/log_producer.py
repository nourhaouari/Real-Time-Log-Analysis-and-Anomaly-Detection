# producers/auto_producer.py

from kafka import KafkaProducer
import json
import time
import random

# Simuler des IPs et URLs
ips = [f"192.168.1.{i}" for i in range(1, 50)]
methods = ['GET', 'POST', 'DELETE', 'PUT']
urls = ['/home', '/about', '/login', '/products', '/contact']
statuses = [200, 201, 400, 401, 403, 404, 500, 502]

# Configurer le producteur Kafka
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda x: json.dumps(x).encode('utf-8'),
    acks='all'
)

def generate_log():
    log = {
        "timestamp": int(time.time()),
        "ip": random.choice(ips),
        "method": random.choice(methods),
        "url": random.choice(urls),
        "status": random.choice(statuses)
    }
    return log

print("Producteur automatique Kafka - Ctrl+C pour quitter")
try:
    while True:
        log = generate_log()
        producer.send("test-topic", value=log)  # ✅ Topic valide ici
        print(f"[LOG] {log}")
        time.sleep(1)  # 1 log/sec
except KeyboardInterrupt:
    print("\nArrêt du producteur auto.")
finally:
    producer.flush()
    producer.close()

