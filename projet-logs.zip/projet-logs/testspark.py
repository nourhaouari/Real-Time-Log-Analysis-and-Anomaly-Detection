import os

os.environ['JAVA_HOME'] = r'D:\java\jdk8'
os.environ['HADOOP_HOME'] = r'D:\hadoop'

from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("Test").getOrCreate()
print(spark.version)

